#include "mainwindow.h"

#include <QMenuBar>
#include <QMenu>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QStandardItem>
#include <QLabel>
#include <QString>
#include <QVariantMap>
#include <QCheckBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    //createCheckBox();  // Add checkbox
    createTreeView();
    createTabWidget();

    // добавляю горизонтальный разделитель
    QSplitter *splitter = new QSplitter(Qt::Horizontal, this);
    splitter->addWidget(treeView);
    splitter->addWidget(tabWidget);
    splitter->setStretchFactor(1, 1);
    splitter->setCollapsible(0, false);
    splitter->setCollapsible(1, false);

    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);
    layout->addWidget(splitter);
    setCentralWidget(centralWidget);

//    // Create the checkbox and add it to the layout
//        hideEmptyFieldsCheckBox = new QCheckBox("Hide empty fields");
//        QHBoxLayout *checkboxLayout = new QHBoxLayout();
//        checkboxLayout->addStretch();
//        checkboxLayout->addWidget(hideEmptyFieldsCheckBox);
//        tab1Layout->addLayout(checkboxLayout);
//        tab2Layout->addLayout(checkboxLayout);
//        tab3Layout->addLayout(checkboxLayout);

//        // Connect the checkbox stateChanged signal to the slot
//        connect(hideEmptyFieldsCheckBox, &QCheckBox::stateChanged, this, &MainWindow::onHideEmptyFieldsClicked);


    // подключаем слот к сигналу clicked дерева
//   connect(treeView, &QTreeView::clicked, this, &MainWindow::onTreeViewItemClicked);
    connect( treeView, SIGNAL( clicked(QModelIndex)),
            this, SLOT( onTreeViewItemClicked(QModelIndex))
             );
    // подключаем слот к сигналу stateChanged чекбокса
       // connect(checkBox, SIGNAL(stateChanged(int)), this, SLOT(onCheckBoxStateChanged(int)));
       // connect(checkBox, &QCheckBox::stateChanged, this, &MainWindow::onHideEmptyFieldsClicked);
}

MainWindow::~MainWindow()
{
}
//QString text = model->itemData(index).value(Qt::DisplayRole).toString();

void MainWindow::createTreeView()
{
    // добавляю дерево списков
    model = new QStandardItemModel(this);
    QStandardItem *rootItem = model->invisibleRootItem();

    QStandardItem *item1 = new QStandardItem("Текст 1");
    rootItem->appendRow(item1);

    QStandardItem *item1_1 = new QStandardItem("Вложенный текст");
    item1->appendRow(item1_1);
    /// вложение во вложение в Текст 1 если нужно
//    QStandardItem *item3 = new QStandardItem(tr("Перевложенный текст"));
//    item1->appendRow(item3);
    QStandardItem *item2 = new QStandardItem("Текст 2");
    rootItem->appendRow(item2);
    QStandardItem *item3 = new QStandardItem("Текст 3");
    rootItem->appendRow(item3);

    treeView = new QTreeView(this);
    treeView->setModel(model);
    treeView->setHeaderHidden(true);
    treeView->setSelectionMode(QAbstractItemView::SingleSelection);
}

void MainWindow::createTabWidget()
{
    // добавляю вкладки
    tabWidget = new QTabWidget(this);

    QWidget *tab1 = new QWidget(tabWidget);
    QWidget *tab2 = new QWidget(tabWidget);
    QWidget *tab3 = new QWidget(tabWidget);
    QWidget *tab4 = new QWidget(tabWidget);
    QWidget *tab5 = new QWidget(tabWidget);

    tabWidget->addTab(tab1, ("Tab1"));
    tabWidget->addTab(tab2, ("Tab 2"));
    tabWidget->addTab(tab3, ("Tab 3"));
    tabWidget->addTab(tab4, ("Tab 4"));
    tabWidget->addTab(tab5, ("Tab 5"));



    QVBoxLayout *tab1Layout = new QVBoxLayout(tab1);
   textTab1Edit1 = new QTextEdit(tab1);
   textTab1Edit2 = new QTextEdit(tab1);
   textTab1Edit3 = new QTextEdit(tab1);

    // добавляю подписи лейблы
   labela1 = new QLabel(("Текст 1:"), tab1);
  labela2 = new QLabel(("Текст 2:"), tab1);
   labela3 = new QLabel(("Текст 3:"), tab1);

    // делаю поля только для чтения
    textTab1Edit1->setReadOnly(true);
    textTab1Edit2->setReadOnly(true);
    textTab1Edit3->setReadOnly(true);

    tab1Layout->addWidget(labela1);
    tab1Layout->addWidget(textTab1Edit1);
    tab1Layout->addWidget(labela2);
    tab1Layout->addWidget(textTab1Edit2);
    tab1Layout->addWidget(labela3);
    tab1Layout->addWidget(textTab1Edit3);
    ///////////////////////////////////////////
    // Добавил виджет флажка в макет
        QCheckBox *hideEmptyFieldsCheckBox = new QCheckBox("Скрыть пустые поля", tab1);
        /// QHBoxLayout *checkboxLayout = new QHBoxLayout;
        /// checkboxLayout->addWidget(hideEmptyFieldsCheckBox);
        /// checkboxLayout->addStretch(1);
        /// tab1Layout->addLayout(checkboxLayout);
        /// connect(hideEmptyFieldsCheckBox, &QCheckBox::toggled, this, &MainWindow::onHideEmptyFieldsToggled);
        // установил флажок в правом нижнем углу виджета вкладки
         tabWidget->setCornerWidget(hideEmptyFieldsCheckBox, Qt::BottomRightCorner);
        tab1Layout->addWidget(hideEmptyFieldsCheckBox);
       tab1Layout->addStretch(1);
    // сигнал нажатия флажка к slot
       connect(hideEmptyFieldsCheckBox, &QCheckBox::clicked, this, &MainWindow::onHideEmptyFieldsClicked);
//tab1Layout->addStretch(1);
//////////////////////////////////////////
// добавил флажок для скрытия пустых полей
//    QCheckBox *checkBox = new QCheckBox("Hide empty fields", tab1);
//    tab1Layout->addWidget(checkBox);

//    connect(checkBox, &QCheckBox::toggled, [this]() {
//        if (textTab1Edit2->toPlainText().isEmpty()) {
//            labela2->hide();
//            textTab1Edit2->hide();
//        } else {
//            labela2->show();
//            textTab1Edit1->show();
//        }
//    });

//    tab1Layout->addStretch(1);
   QVBoxLayout *tab2Layout = new QVBoxLayout(tab2);
    textTab2Edit1 = new QTextEdit(tab2);
    textTab2Edit2 = new QTextEdit(tab2);
    textTab2Edit3 = new QTextEdit(tab2);


   labelb1 = new QLabel(("Текст 1:"), tab2);
    labelb2 = new QLabel(("Текст 2:"), tab2);
   labelb3 = new QLabel(("Текст 3:"), tab2);

    textTab2Edit2->setReadOnly(true);
    textTab2Edit3->setReadOnly(true);

    tab2Layout->addWidget(labelb1);
    tab2Layout->addWidget(textTab2Edit1);
    tab2Layout->addWidget(labelb2);
    tab2Layout->addWidget(textTab2Edit2);
    tab2Layout->addWidget(labelb3);
    tab2Layout->addWidget(textTab2Edit3);
    tab2Layout->addStretch(1);


    QVBoxLayout *tab3Layout = new QVBoxLayout(tab3);
    textTab3Edit1 = new QTextEdit(tab3);
    textTab3Edit2 = new QTextEdit(tab3);
    textTab3Edit3 = new QTextEdit(tab3);


   labelc1 = new QLabel(("Текст 1:"), tab3);
    labelc2 = new QLabel(("Текст 2:"), tab3);
   labelc3 = new QLabel(("Текст 3:"), tab3);


    textTab3Edit2->setReadOnly(true);
    textTab3Edit3->setReadOnly(true);

    // устанавливаю layouts
    tab3Layout->addWidget(labelc1);
    tab3Layout->addWidget(textTab3Edit1);
    tab3Layout->addWidget(labelc2);
    tab3Layout->addWidget(textTab3Edit2);
    tab3Layout->addWidget(labelc3);
    tab3Layout->addWidget(textTab3Edit3);
    tab3Layout->addStretch(1);
//    // добавил checkbox widget
//    checkBox = new QCheckBox("Скрыть пустые поля", tabWidget);
//    // Добавил виджет флажка в макет layout
//    QVBoxLayout *mainLayout = new QVBoxLayout(tab1);
//    mainLayout->addWidget(checkBox);
   }
void MainWindow::onHideEmptyFieldsClicked()
{
    // Check if the checkbox is checked
        bool hideEmptyFields = static_cast<QCheckBox*>(sender())->isChecked();

        // Check if the current tab is tab1
        if (tabWidget->currentIndex() == 0)
        {
            // Hide or show the fields based on the checkbox status
            if (hideEmptyFields)
            {
                if (textTab1Edit1->toPlainText().isEmpty())
                {
                    textTab1Edit1->hide();
                    labela1->hide();
                }
                if (textTab1Edit2->toPlainText().isEmpty())
                {
                    textTab1Edit2->hide();
                    labela2->hide();
                }
                if (textTab1Edit3->toPlainText().isEmpty())
                {
                    textTab1Edit3->hide();
                   labela3->hide();
                }
            }
            else
            {
                textTab1Edit1->show();
                labela1->show();
                textTab1Edit2->show();
                labela2->show();
                textTab1Edit3->show();
                labela3->show();
            }
        }
}

void MainWindow::onHideEmptyFieldsToggled(bool checked)
{
    if (checked) {
            // скрываю пустые поля
            if (textTab1Edit1->toPlainText().isEmpty()) {
                textTab1Edit1->hide();
                labela1->hide();
            }
            // иначе show
        } else {
            // Show all fields
            textTab1Edit1->show();
            labela1->show();
            // Можно повторить для других полей по мере необходимости
        }
}

void MainWindow::onTreeViewItemClicked(const QModelIndex &modelIndex)
{

        QString text;

        // Заполняет выборочно
        if (modelIndex.row() == 0)
        {
          textTab1Edit1->setText( modelIndex.data().toString() );
          // text = QString("Текст 1 вставка");
//          text =  modelIndex.data().toString();
//          textTab1Edit1->setText(text);
        }
        else if (modelIndex.row() == 1)
        {
            text = QString("Текст 2 вставка");
        }
        else if (modelIndex.row() == 2)
        {
            text = QString("Текст 3 вставка");
            textTab3Edit3->setText(text);
        }
}




        // выбор полей для заполнения
//        textTab1Edit1->setText(text);
//        textTab1Edit2->setText(text);
//        textTab2Edit3->setText(text);

//    // получаем текст элемента дерева

//    QString text = model->itemData(modelIndex).value(Qt::DisplayRole).toString();
//        // вставляем текст в соответствующее поле вкладки
//        if (text == "Текст 1")
//        {
//            textTab1Edit1->setText("Текст для Tab 1, TextEdit 1");
//        }
//        else if (text == "Текст 2")
//        {
//            textTab1Edit2->setText("Текст для Tab 1, TextEdit 2");
//        }
//        else if (text == "Вложенный текст")
//        {
//            textTab1Edit3->setText("Текст для Tab 1, TextEdit 3");
//        }
//        else if (text == "Вложенный текст")
//        {
//            textTab2Edit3->setText("Текст для Tab 2, TextEdit 3");
//        }

//  textTab1Edit1->setText( modelIndex.data().toString() );
//  textTab1Edit2->setText( modelIndex.data().toString() );
//  textTab1Edit3->setText( modelIndex.data().toString() );
//  textTab2Edit3->setText( modelIndex.data().toString() );
//}


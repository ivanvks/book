#include "mainwindow.h"
#include "mytext.h"

#include <QMenuBar>
#include <QMenu>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QStandardItem>
#include <QLabel>
#include <QDebug>
#include <QWidget>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    createMenu();
    createTreeView();
    createTabWidget();

    // добавляю горизонтальный разделитель
    QSplitter *splitter = new QSplitter(Qt::Horizontal, this);
    splitter->addWidget(treeView);
    splitter->addWidget(tabWidget);
    splitter->setStretchFactor(1, 1);
    splitter->setCollapsible(0, false);
    splitter->setCollapsible(1, false);

    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);
    layout->addWidget(splitter);
    setCentralWidget(centralWidget);

    connect( treeView, SIGNAL( clicked(QModelIndex)),
             this, SLOT( updateTabWidget(QModelIndex))
             );
}

MainWindow::~MainWindow()
{
}

void MainWindow::createMenu()
{
    // Create File menu and actions
    QMenu *fileMenu = menuBar()->addMenu("&File");

//    QAction *newAction = new QAction(tr("&Создать"), this);
//    fileMenu->addAction(newAction);

//    QAction *openAction = new QAction(tr("&Открыть"), this);
//    fileMenu->addAction(openAction);

//    QAction *saveAction = new QAction(tr("&Сохранить"), this);
//    fileMenu->addAction(saveAction);

    QAction *exitAction = new QAction(("&Exit"), this);
    fileMenu->addAction(exitAction);

    // Подключаю сигнал слот
    connect(exitAction, &QAction::triggered, this, &QWidget::close);
}

void MainWindow::createTreeView()
{
    // добавляю дерево списков
    model = new QStandardItemModel(this);
    QStandardItem *rootItem = model->invisibleRootItem();
    /// вставка текста из хедерника
//    MyText myTextObject;
//    QStandardItem *item1 = new QStandardItem(myTextObject.getText());

    QStandardItem *item1 = new QStandardItem("Текст 1");
    rootItem->appendRow(item1);

    QStandardItem *item1_1 = new QStandardItem("Вложенный текст");
    item1->appendRow(item1_1);
    /// вложение во вложение в Текст 1 если нужно
//    QStandardItem *item3 = new QStandardItem(tr("Перевложенный текст"));
//    item1->appendRow(item3);
    QStandardItem *item2 = new QStandardItem("Текст 2");
    rootItem->appendRow(item2);

    treeView = new QTreeView(this);
    treeView->setModel(model);
    treeView->setHeaderHidden(true);
    treeView->setSelectionMode(QAbstractItemView::SingleSelection);
}

//void MainWindow::createTabWidget()
//{
//    // добавляю вкладки
//    tabWidget = new QTabWidget(this);

//    QWidget *tab1 = new QWidget(tabWidget);
//    QWidget *tab2 = new QWidget(tabWidget);
//    QWidget *tab3 = new QWidget(tabWidget);
//    QWidget *tab4 = new QWidget(tabWidget);
//    QWidget *tab5 = new QWidget(tabWidget);

//    tabWidget->addTab(tab1, ("Tab1"));
//    tabWidget->addTab(tab2, ("Tab 2"));
//    tabWidget->addTab(tab3, ("Tab 3"));
//    tabWidget->addTab(tab4, ("Tab 4"));
//    tabWidget->addTab(tab5, ("Tab 5"));


//    QVBoxLayout *tab1Layout = new QVBoxLayout(tab1);
//    QTextEdit *textTab1Edit1 = new QTextEdit(tab1);
//    QTextEdit *textTab1Edit2 = new QTextEdit(tab1);
//    QTextEdit *textTab1Edit3 = new QTextEdit(tab1);

//    // добавляю подписи лейблы
//    QLabel *labela1 = new QLabel(("Текст 1:"), tab1);
//    QLabel *labela2 = new QLabel(("Текст 2:"), tab1);
//    QLabel *labela3 = new QLabel(("Текст 3:"), tab1);

//    // делаю поля только для чтения
//    textTab1Edit2->setReadOnly(true);
//    textTab1Edit3->setReadOnly(true);

//    tab1Layout->addWidget(labela1);
//    tab1Layout->addWidget(textTab1Edit1);
//    tab1Layout->addWidget(labela2);
//    tab1Layout->addWidget(textTab1Edit2);
//    tab1Layout->addWidget(labela3);
//    tab1Layout->addWidget(textTab1Edit3);
//    tab1Layout->addStretch(1);

//    QVBoxLayout *tab2Layout = new QVBoxLayout(tab2);
//    QTextEdit *textTab2Edit1 = new QTextEdit(tab2);
//    QTextEdit *textTab2Edit2 = new QTextEdit(tab2);
//    QTextEdit *textTab2Edit3 = new QTextEdit(tab2);


//    QLabel *labelb1 = new QLabel(("Текст 1:"), tab2);
//    QLabel *labelb2 = new QLabel(("Текст 2:"), tab2);
//    QLabel *labelb3 = new QLabel(("Текст 3:"), tab2);

//    textTab2Edit2->setReadOnly(true);
//    textTab2Edit3->setReadOnly(true);

//    tab2Layout->addWidget(labelb1);
//    tab2Layout->addWidget(textTab2Edit1);
//    tab2Layout->addWidget(labelb2);
//    tab2Layout->addWidget(textTab2Edit2);
//    tab2Layout->addWidget(labelb3);
//    tab2Layout->addWidget(textTab2Edit3);
//    tab2Layout->addStretch(1);


//    QVBoxLayout *tab3Layout = new QVBoxLayout(tab3);
//    QTextEdit *textTab3Edit1 = new QTextEdit(tab3);
//    QTextEdit *textTab3Edit2 = new QTextEdit(tab3);
//    QTextEdit *textTab3Edit3 = new QTextEdit(tab3);


//    QLabel *labelc1 = new QLabel(("Текст 1:"), tab3);
//    QLabel *labelc2 = new QLabel(("Текст 2:"), tab3);
//    QLabel *labelc3 = new QLabel(("Текст 3:"), tab3);


//    textTab3Edit2->setReadOnly(true);
//    textTab3Edit3->setReadOnly(true);

//    // устанавливаю layouts
//    tab3Layout->addWidget(labelc1);
//    tab3Layout->addWidget(textTab3Edit1);
//    tab3Layout->addWidget(labelc2);
//    tab3Layout->addWidget(textTab3Edit2);
//    tab3Layout->addWidget(labelc3);
//    tab3Layout->addWidget(textTab3Edit3);
//    tab3Layout->addStretch(1);
//    }
void MainWindow::createTabWidget()
{
    int tabNum = 0;
    tabWidget = new QTabWidget(this);
    const QStringList tabNames = {"Tab1", "Tab 2", "Tab 3", "Tab 4", "Tab 5"};
    for (const auto &tabName : tabNames) {
        QWidget *widget = new QWidget(tabWidget);
        textEdit1 = new QTextEdit(widget);
        textEdit2 = new QTextEdit(widget);
        textEdit3 = new QTextEdit(widget);
//   textTab1Edit1 = new QTextEdit(widget);
        QLabel *label1 = new QLabel("Текст 1:", widget);
        QLabel *label2 = new QLabel("Текст 2:", widget);
        QLabel *label3 = new QLabel("Текст 3:", widget);
        textEdit1->setReadOnly(true);
////       textEdit1->setObjectName( QString( "textEdit" ).append(
////                                      QString::number( ++tabNum ) ) );
        textEdit2->setReadOnly(true);
        textEdit3->setReadOnly(true);
//        textTab1Edit1->setReadOnly(true);
        QVBoxLayout *layout = new QVBoxLayout(widget);
        layout->addWidget(label1);
//        layout->addWidget(textTab1Edit1);
       layout->addWidget(textEdit1);
        layout->addWidget(label2);
        layout->addWidget(textEdit2);
        layout->addWidget(label3);
        layout->addWidget(textEdit3);
        layout->addStretch(1);
        tabWidget->addTab(widget, tabName);
    }
}

void MainWindow::updateTabWidget( const QModelIndex &modelIndex )
{
//    MyText myTextObject;
//    qDebug() << modelInsex.data();

//    foreach ( const QObject *obj, tabWidget->widget( 0 )->children() ) {
//        qDebug() << obj->objectName();
//        if ( obj->objectName().contains( "textEdit1" ) )
//            QTextEdit textEditN = new QTextEdit(
//                        static_cast < QTextEdit > obj );
//        textEditN.setText( "addd" );
//    }
textEdit1->setText( modelIndex.data().toString() );
//textTab1Edit1->setText( myTextObject.getText());

//    QTextEdit *textEditN = new QTextEdit(
//                tabWidget->widget( 0 )->findChild
//                );

//    textEditN->setText( modelInsex.data().toString() );
    /// вставка текста из хедерника


}

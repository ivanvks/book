#ifndef MYTEXT_H
#define MYTEXT_H

#include <QString>

class MyText
{
public:
    QString getText() const
{
    return "Мой текст";
}
};


#endif // MYTEXT_H

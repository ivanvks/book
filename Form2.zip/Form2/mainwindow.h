#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTreeView>
#include <QStandardItemModel>
#include <QTabWidget>
#include <QLineEdit>
#include <QTextEdit>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    void createMenu();
    void createTreeView();
    void createTabWidget();

    QTreeView *treeView;
    QStandardItemModel *model;
    QTabWidget *tabWidget;
    QTextEdit *textTab1Edit1;
    QTextEdit *texTab1tEdit2;
    QTextEdit *textTab1Edit3;
    QTextEdit *textTab2Edit1;
    QTextEdit *textTab2Edit2;
    QTextEdit *texTab2Edit3;
    QTextEdit *textTab3Edit1;
    QTextEdit *textTab3Edit2;
    QTextEdit *textTab3Edit3;
    QTextEdit *textTab4Edit1;
    QTextEdit *textTab4Edit2;
    QTextEdit *textTab4Edit3;
    QTextEdit *textTab5Edit1;
    QTextEdit *textTab5Edit2;
    QTextEdit *textTab5Edit3;
};
#endif // MAINWINDOW_H

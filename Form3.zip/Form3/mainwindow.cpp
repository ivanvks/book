#include "mainwindow.h"

#include <QMenuBar>
#include <QMenu>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QStandardItem>
#include <QLabel>
#include <QString>
#include <QVariantMap>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    createTreeView();
    createTabWidget();

    // добавляю горизонтальный разделитель
    QSplitter *splitter = new QSplitter(Qt::Horizontal, this);
    splitter->addWidget(treeView);
    splitter->addWidget(tabWidget);
    splitter->setStretchFactor(1, 1);
    splitter->setCollapsible(0, false);
    splitter->setCollapsible(1, false);

    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);
    layout->addWidget(splitter);
    setCentralWidget(centralWidget);

    // подключаем слот к сигналу clicked дерева
//   connect(treeView, &QTreeView::clicked, this, &MainWindow::onTreeViewItemClicked);
    connect( treeView, SIGNAL( clicked(QModelIndex)),
            this, SLOT( onTreeViewItemClicked(QModelIndex))
             );
}

MainWindow::~MainWindow()
{
}
//QString text = model->itemData(index).value(Qt::DisplayRole).toString();

void MainWindow::createTreeView()
{
    // добавляю дерево списков
    model = new QStandardItemModel(this);
    QStandardItem *rootItem = model->invisibleRootItem();

    QStandardItem *item1 = new QStandardItem("Текст 1");
    rootItem->appendRow(item1);

    QStandardItem *item1_1 = new QStandardItem("Вложенный текст");
    item1->appendRow(item1_1);
    /// вложение во вложение в Текст 1 если нужно
//    QStandardItem *item3 = new QStandardItem(tr("Перевложенный текст"));
//    item1->appendRow(item3);
    QStandardItem *item2 = new QStandardItem("Текст 2");
    rootItem->appendRow(item2);
    QStandardItem *item3 = new QStandardItem("Текст 3");
    rootItem->appendRow(item3);

    treeView = new QTreeView(this);
    treeView->setModel(model);
    treeView->setHeaderHidden(true);
    treeView->setSelectionMode(QAbstractItemView::SingleSelection);
}

void MainWindow::createTabWidget()
{
    // добавляю вкладки
    tabWidget = new QTabWidget(this);

    QWidget *tab1 = new QWidget(tabWidget);
    QWidget *tab2 = new QWidget(tabWidget);
    QWidget *tab3 = new QWidget(tabWidget);
    QWidget *tab4 = new QWidget(tabWidget);
    QWidget *tab5 = new QWidget(tabWidget);

    tabWidget->addTab(tab1, ("Tab1"));
    tabWidget->addTab(tab2, ("Tab 2"));
    tabWidget->addTab(tab3, ("Tab 3"));
    tabWidget->addTab(tab4, ("Tab 4"));
    tabWidget->addTab(tab5, ("Tab 5"));


    QVBoxLayout *tab1Layout = new QVBoxLayout(tab1);
   textTab1Edit1 = new QTextEdit(tab1);
   textTab1Edit2 = new QTextEdit(tab1);
   textTab1Edit3 = new QTextEdit(tab1);

    // добавляю подписи лейблы
    QLabel *labela1 = new QLabel(("Текст 1:"), tab1);
    QLabel *labela2 = new QLabel(("Текст 2:"), tab1);
    QLabel *labela3 = new QLabel(("Текст 3:"), tab1);

    // делаю поля только для чтения
    textTab1Edit1->setReadOnly(true);
    textTab1Edit2->setReadOnly(true);
    textTab1Edit3->setReadOnly(true);

    tab1Layout->addWidget(labela1);
    tab1Layout->addWidget(textTab1Edit1);
    tab1Layout->addWidget(labela2);
    tab1Layout->addWidget(textTab1Edit2);
    tab1Layout->addWidget(labela3);
    tab1Layout->addWidget(textTab1Edit3);
    tab1Layout->addStretch(1);

    QVBoxLayout *tab2Layout = new QVBoxLayout(tab2);
    textTab2Edit1 = new QTextEdit(tab2);
    textTab2Edit2 = new QTextEdit(tab2);
    textTab2Edit3 = new QTextEdit(tab2);


    QLabel *labelb1 = new QLabel(("Текст 1:"), tab2);
    QLabel *labelb2 = new QLabel(("Текст 2:"), tab2);
    QLabel *labelb3 = new QLabel(("Текст 3:"), tab2);

    textTab2Edit2->setReadOnly(true);
    textTab2Edit3->setReadOnly(true);

    tab2Layout->addWidget(labelb1);
    tab2Layout->addWidget(textTab2Edit1);
    tab2Layout->addWidget(labelb2);
    tab2Layout->addWidget(textTab2Edit2);
    tab2Layout->addWidget(labelb3);
    tab2Layout->addWidget(textTab2Edit3);
    tab2Layout->addStretch(1);


    QVBoxLayout *tab3Layout = new QVBoxLayout(tab3);
    textTab3Edit1 = new QTextEdit(tab3);
    textTab3Edit2 = new QTextEdit(tab3);
    textTab3Edit3 = new QTextEdit(tab3);


    QLabel *labelc1 = new QLabel(("Текст 1:"), tab3);
    QLabel *labelc2 = new QLabel(("Текст 2:"), tab3);
    QLabel *labelc3 = new QLabel(("Текст 3:"), tab3);


    textTab3Edit2->setReadOnly(true);
    textTab3Edit3->setReadOnly(true);

    // устанавливаю layouts
    tab3Layout->addWidget(labelc1);
    tab3Layout->addWidget(textTab3Edit1);
    tab3Layout->addWidget(labelc2);
    tab3Layout->addWidget(textTab3Edit2);
    tab3Layout->addWidget(labelc3);
    tab3Layout->addWidget(textTab3Edit3);
    tab3Layout->addStretch(1);
    }

void MainWindow::onTreeViewItemClicked(const QModelIndex &modelIndex)
{

        QString text;

        // Заполняет выборочно
        if (modelIndex.row() == 0)
        {
          textTab1Edit1->setText( modelIndex.data().toString() );
          // text = QString("Текст 1 вставка");
//          text =  modelIndex.data().toString();
//          textTab1Edit1->setText(text);
        }
        else if (modelIndex.row() == 1)
        {
            text = QString("Текст 2 вставка");
        }
        else if (modelIndex.row() == 2)
        {
            text = QString("Текст 3 вставка");
            textTab3Edit3->setText(text);
        }

        // выбор полей для заполнения
//        textTab1Edit1->setText(text);
//        textTab1Edit2->setText(text);
//        textTab2Edit3->setText(text);

//    // получаем текст элемента дерева

//    QString text = model->itemData(modelIndex).value(Qt::DisplayRole).toString();
//        // вставляем текст в соответствующее поле вкладки
//        if (text == "Текст 1")
//        {
//            textTab1Edit1->setText("Текст для Tab 1, TextEdit 1");
//        }
//        else if (text == "Текст 2")
//        {
//            textTab1Edit2->setText("Текст для Tab 1, TextEdit 2");
//        }
//        else if (text == "Вложенный текст")
//        {
//            textTab1Edit3->setText("Текст для Tab 1, TextEdit 3");
//        }
//        else if (text == "Вложенный текст")
//        {
//            textTab2Edit3->setText("Текст для Tab 2, TextEdit 3");
//        }

//  textTab1Edit1->setText( modelIndex.data().toString() );
//  textTab1Edit2->setText( modelIndex.data().toString() );
//  textTab1Edit3->setText( modelIndex.data().toString() );
//  textTab2Edit3->setText( modelIndex.data().toString() );
}

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTreeView>
#include <QStandardItemModel>
#include <QTabWidget>
#include <QLineEdit>
#include <QTextEdit>
#include <QWidget>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    void createTreeView();
    void createTabWidget();

private slots:
   void onTreeViewItemClicked(const QModelIndex &modelIndex);

private:
//    QVariantMap *itemData;
    QTreeView *treeView;
    QStandardItemModel *model;
    QTabWidget *tabWidget;
    QTextEdit *textTab1Edit1, *textTab1Edit2, *textTab1Edit3;
    QTextEdit *textTab2Edit1, *textTab2Edit2, *textTab2Edit3;
    QTextEdit *textTab3Edit1, *textTab3Edit2, *textTab3Edit3;
    QTextEdit *textTab4Edit1, *textTab4Edit2, *textTab4Edit3;
    QTextEdit *textTab5Edit1, *textTab5Edit2, *textTab5Edit3;
};

#endif // MAINWINDOW_H

#ifndef TEXTEDITOR_H
#define TEXTEDITOR_H

#include <QtWidgets>
#include <QtGui>
#include <QPushButton>
#include <QMessageBox>

class TextEditor : public QWidget
{
    Q_OBJECT
public:
    explicit TextEditor(QWidget *parent = nullptr);

private:
    QGridLayout *mainGrid;

    QPushButton *buttonOpen;
    QPushButton *buttonSave;
    QPushButton *buttonHelp;

    QPlainTextEdit *editor;


public slots:
    void on_buttonOpen_clicked();
    void on_buttonSave_clicked();
    void on_buttonHelp_clicked();

};

#endif // TEXTEDITOR_H
